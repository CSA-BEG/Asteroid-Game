import pygame, sys
from pygame.locals import *
import time
import random

'''-----------------------------------------------------------------
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
-----------------------------------------------------------------'''

background = (0, 0, 0)
entity_color = (255, 255, 255)
WHITE = (255, 255, 255)#colors and pictures setup
GRAY = (211,211,211)
GREY = (170,170,170)
RED = (255,0,0)
BLACK = (0,0,0)

class Entity(pygame.sprite.Sprite):
    """Inherited by any object in the game."""

    def __init__(self, x, y, width, height):
        pygame.sprite.Sprite.__init__(self)

        self.x = x
        self.y = y
        self.width = width
        self.height = height

        # This makes a rectangle around the entity, used for anything
        # from collision to moving around.
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)


class Paddle(Entity):
    """
    Player controlled or AI controlled, main interaction with
    the game
    """

    def __init__(self, x, y, width, height):
        super(Paddle, self).__init__(x, y, width, height)

        self.image = pygame.image.load('xwing.png')


class Player(Paddle):
    """The player controlled Paddle"""

    def __init__(self, x, y, width, height):
        super(Player, self).__init__(x, y, width, height)

        # How many pixels the Player Paddle should move on a given frame.
        self.y_change = 0
        # How many pixels the paddle should move each frame a key is pressed.
        self.y_dist = 5

    def MoveKeyDown(self, key):
        """Responds to a key-down event and moves accordingly"""
        if (key == pygame.K_UP):
            self.y_change += -self.y_dist
        elif (key == pygame.K_DOWN):
            self.y_change += self.y_dist

    def MoveKeyUp(self, key):
        """Responds to a key-up event and stops movement accordingly"""
        if (key == pygame.K_UP):
            self.y_change += self.y_dist
        elif (key == pygame.K_DOWN):
            self.y_change += -self.y_dist

    def shoot(self,key):
        if (key==pygame.K_z):
            pass

    def update(self):
        """
        Moves the paddle while ensuring it stays in bounds
        """
        # Moves it relative to its current location.
        self.rect.move_ip(0, self.y_change)

        # If the paddle moves off the screen, put it back on.
        if self.rect.y < 0:
            self.rect.y = 0
        elif self.rect.y > window_height - self.height:
            self.rect.y = window_height - self.height
    def getXY(self):
        mousex=self.x
        mousey=self.y
        shots=[mousex,mousey]
        return shots

class Bullet(pygame.sprite.Sprite):
    """ This class represents the bullet . """

    def __init__(self):
        # Call the parent class (Sprite) constructor
        super().__init__()

        self.image = pygame.image.load('lazer.jpg')

        self.rect = self.image.get_rect()

    def update(self):
        """ Move the bullet. """
        self.rect.x += 17

class Ball(Entity):
    """
    The ball!  Moves around the screen.
    """

    def __init__(self, x, y, width, height,color):
        super(Ball, self).__init__(x, y, width, height)

        self.image = pygame.Surface([width, height])
        self.image.fill(color)

    def update(self):
        # Move the ball!
        self.rect.x-=9

    def quickCheck1(self):
        if self.rect.x < 0:
            return True

def makeAsteroid():
    global all_sprites_list
    global ball_list
    global makemore
    special=random.randint(0, 200)
    if special<=10:
        makeSpecial()
    bally = random.randint(30, 450)
    while bally <= f.rect.y + 50 and bally >= f.rect.y - 50:
        bally = random.randint(30, 450)
    ball = Ball(window_width - 1, bally, 20, 20,entity_color)
    all_sprites_list.add(ball)
    ball_list.add(ball)


def makeSpecial():
    global all_sprites_list
    global special_list
    bally = random.randint(30, 450)
    while bally <= f.rect.y + 50 and bally >= f.rect.y - 50:
        bally = random.randint(30, 450)
    ball = Ball(window_width - 1, bally, 20, 20,RED)
    all_sprites_list.add(ball)
    special_list.add(ball)


def highscores(what):
    global score
    global text5
    if what==1:
        file = open("highscores.txt", 'r')
        line=file.readline()
        file.close()
        line=line.split(',')
        for r in range(10):
            rint=int(line[0])
            line.remove(line[0])
            line.append(rint)
        line.append(int(score))
        line.sort(reverse=True)
        del line[-1]
        for q in range(len(line)):
            if int(score)==line[q]:
                place=q
        line=str(line)
        line=line.replace("[","")
        line=line.replace("]","")
        line=line.replace(" ","")
        file=open("highscores.txt", 'w')
        file.write(line)
        file.close()
        if place==0:
            place+=1
        try:
            text5=text.render(('Place = '+str(place)),6,WHITE)
        except:
            text5=text.render(('No Highscore'),6,WHITE)

pygame.init()

pygame.mixer.music.load('shooting sandstorms.wav')
pygame.mixer.music.play(-1, 0.0)
soundObj = pygame.mixer.Sound('rdse.wav')

lives=3
score=0
makemore=0

bullet_list = pygame.sprite.Group()
ball_list=pygame.sprite.Group()

special_list=pygame.sprite.Group()

window_width = 900
window_height = 500
screen = pygame.display.set_mode((window_width, window_height))
text=pygame.font.Font(None, 45)
texts=pygame.font.Font(None, 120 )
text2=text.render("Lives"+str(lives),6,WHITE)

pygame.display.set_caption("This Might Be An Asteroid Game")

clock = pygame.time.Clock()
ball = Ball(window_width-1, random.randint(30, 450), 20, 20,entity_color)
ball_list.add(ball)
player = Player(20, window_height / 2, 80, 74)

all_sprites_list = pygame.sprite.Group()
all_sprites_list.add(ball)
all_sprites_list.add(player)
brek=False
while True:
    while brek==False:
        title=texts.render("Asteroids",6,WHITE)
        screen.blit(title,(10,10))
        pygame.draw.rect(screen, GRAY, (10, 90, 85, 40))
        button=text.render("Start",6,WHITE)
        screen.blit(button,(15,95))
        instructions=text.render("Up/Down to move, Z to shoot",6,WHITE)
        screen.blit(instructions,(10,135))
        file=open('highscores.txt','r')
        line=file.readline()
        line=line.split(',')
        score1=text.render('1. '+line[0],6,WHITE)
        screen.blit(score1,(10,175))

        score2=text.render('2. '+line[1],6,WHITE)
        screen.blit(score2,(10,205))

        score3=text.render('3. '+line[2],6,WHITE)
        screen.blit(score3,(10,235))

        score4=text.render('4. '+line[3],6,WHITE)
        screen.blit(score4,(10,265))

        score5=text.render('5. '+line[4],6,WHITE)
        screen.blit(score5,(10,295))

        score6=text.render('6. '+line[5],6,WHITE)
        screen.blit(score6,(10,325))

        score7=text.render('7. '+line[6],6,WHITE)
        screen.blit(score7,(10,355))

        score8=text.render('8. '+line[7],6,WHITE)
        screen.blit(score8,(10,385))

        score9=text.render('9. '+line[8],6,WHITE)
        screen.blit(score9,(10,415))

        score10=text.render('10. '+line[9],6,WHITE)
        screen.blit(score10,(10,445))
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONDOWN:
                mx, my = event.pos
                if mx >= 10 and mx <= 95 and my >= 90 and my <= 130:
                    pygame.draw.rect(screen, GRAY, (10, 90, 85, 40))
                    pygame.display.flip()
                    brek=True
            if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()
        if brek==True:
            break

    # Event processing here
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN and event.key == K_z:
            bullet = Bullet()
            bullet.rect.x = player.rect.x+65
            bullet.rect.y = player.rect.y+35
            all_sprites_list.add(bullet)
            bullet_list.add(bullet)
            soundObj.play()
        elif event.type == pygame.KEYDOWN and event.key == K_q:
            lives=1
        elif event.type == pygame.KEYDOWN and event.key == K_w:
            score+=200
        elif event.type == pygame.KEYDOWN:
            player.shoot(event.key)
            player.MoveKeyDown(event.key)
        elif event.type == pygame.KEYUP:
            player.shoot(event.key)
            player.MoveKeyUp(event.key)

    for ent in all_sprites_list:
        ent.update()

    while len(ball_list)<(makemore/40):
        if len(ball_list)>=7:
            break
        else:
            makeAsteroid()

    for i in bullet_list:
        if i.rect.x >= 900:
            i.remove(all_sprites_list)
            bullet_list.remove(i)

    for f in ball_list:
        if f.rect.x <= 0:
            f.remove(all_sprites_list)
            score-=100
            ball_list.remove(f)
            makeAsteroid()

    for i in ball_list:
        for x in bullet_list:
            if i.rect.colliderect(x):
                i.remove(all_sprites_list)
                score+=100
                x.remove(all_sprites_list)
                ball_list.remove(i)
                bullet_list.remove(x)
                sound=pygame.mixer.Sound('headshot.wav')
                sound.play()
                makeAsteroid()

    for i in special_list:
        for x in bullet_list:
            if i.rect.colliderect(x):
                i.remove(all_sprites_list)
                score+=1000
                x.remove(all_sprites_list)
                ball_list.remove(i)
                bullet_list.remove(x)
                sound4=pygame.mixer.Sound('yeay.wav')
                sound4.play()
                makeAsteroid()

    for i in ball_list:
        if i.rect.colliderect(player.rect):
            ball_list.remove(i)
            i.remove(all_sprites_list)
            killed = True
            death=pygame.mixer.Sound('boom.wav')
            death.play()
            lives -= 1
            makeAsteroid()
            if lives == 0:
                f=0
                pygame.mixer.music.stop()
                pygame.mixer.music.load('there is no need to be upset.wav')
                pygame.mixer.music.play(-1, 0.0)
                while True:
                    f+=1
                    highscores(f)
                    text3 = texts.render("Game Over", 6, WHITE)
                    screen.fill(background)
                    screen.blit(text3, (10, 10))
                    screen.blit(text4,(10,90))
                    screen.blit(text5,(10,130))
                    screen.blit(text6,(10,170))
                    pygame.display.flip()
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == K_ESCAPE):
                            pygame.quit()
                            sys.exit()

    makemore+=1
    text2=text.render("Lives "+str(lives),6,WHITE)
    text4=text.render("Score "+str(score),6,WHITE)
    text6=text.render("Press ESC to quit",6,WHITE)
    screen.fill(background)
    screen.blit(text4,(140,10))
    screen.blit(text2,(10,10))
    all_sprites_list.draw(screen)
    pygame.display.flip()
    clock.tick(30)
